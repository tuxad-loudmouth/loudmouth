$TESTING = true
$:.push File.join(File.dirname(__FILE__), '..', 'lib')

require 'rubygems'
require 'pp'
require 'yaml'
require 'spec'
#require 'glib2'
